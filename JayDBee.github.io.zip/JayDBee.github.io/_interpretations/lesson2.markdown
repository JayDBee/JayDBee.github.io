---
layout: lesson
title: Lesson 2
---

## W2

Now that we better understand what interpretations are, we can better use these activities to tailor them to ourselves. I encourage the reader to keep a journal of their own ideas and date them, so they are able to easily remember what changes have occurred that made their opinions to change. By now, taking some time away from this course, we may have realized that we change in our opinions very drastically even though we are the same person. This exact change of state of mind is what we try to understand in this course.

If we are to build with and from our interpretations, we can consider variation as our first obstacle. Luckily, here, we only consider a passive interaction through our faculties which means that we are not in charge of making creative work such as drawings, acting, music, puzzles, etc. With these mediums, we are only concerned with the interacting with them through observation.

In this lesson, exposure is greatly encouraged, for these activities, the more exposure the better. The goal being, if we are to build, that we want to better understand what brings us to interpret more times than others. When is it more fun, or when is there a gap between our thoughts and actions? We could for example, take inspiration from activities we enjoy, and vary them. For example, if I like to watch movies, does watching many different genres change my enjoyment, compared to re-watching a movie or watching movies in the same genre?

Review W1 through this week to attach definitions to interpretations brought by each activities.

To do
- when do we create? Week 7-8?
